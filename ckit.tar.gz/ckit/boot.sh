qemu-system-i386  -kernel ./static/vmlinuz -initrd initrd.gz
