apt-get install build-essential gcc-multilib qemu
