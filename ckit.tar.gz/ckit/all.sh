fakeroot ./build.sh
./boot.sh
